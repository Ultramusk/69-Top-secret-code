module.exports = {
  "token": "ODc5MjA2ODg4MDExNjI4NTQ0.YSMXOA.5IBLkLKDQPeDs-9xY678s3lvv4g",
  "clientSecret": "",
  "statusHook": "https://discord.com/api/webhooks/917372617365815326/9Ebv23g45RCUcWvlwO2P-PedL4YrxmV1sz88tUr2YDrkidO6XcDWubKF1NMWyaiRfDUk",
  "clientId": "906782668312698911",
  "status": "You | /help!",
  "statusType": "WATCHING",
  "mongoSrv": `mongodb+srv://root:<password>@bot-list.24c2z.mongodb.net/ultramuskbot?retryWrites=true&w=majority`
}