module.exports = {
  general: "<:gadgetprologo:912620044767354900>",
  leveling: "<:ranking:910800763964497951>",
  music: "<:music:910800762907533343>",
  mod: "<:mod:910801693757816832>",
  utility: "<:utility:910800766648872960>",
  owner: "<:owner:910800763821916170>",
  giveaway: "<:giveaway:910800761062055966>",
  backup: "<:cloudpng:910805715839483914>",
  error: "<a:gadget_error:910730595024392202>",
  welcomer: "<:welcome:910800772172771338>",
  economy: "<:economy:910800774664175637>",
  nqn: "<:nqn:910800769484226560>",
  modlogs: "<:modlogs:910800774651576330>",
  chatbot: "<:chatbot:910800760466472981>",
  youtube: "<:together:910800779512807484>",
  autorole: "<:autorole:910800771199692821>"
};